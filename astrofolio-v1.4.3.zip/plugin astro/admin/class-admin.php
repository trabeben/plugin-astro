<?php

/**
 * Classe d'administration pour AstroFolio
 * Version simple et fonctionnelle
 */
class Astro_Admin {

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    public function add_admin_menu() {
        // Page principale
        add_menu_page(
            'AstroFolio',
            'AstroFolio',
            'manage_options',
            'astrofolio',
            array($this, 'dashboard_page'),
            'dashicons-camera',
            30
        );

        // Sous-pages
        add_submenu_page(
            'astrofolio',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'astrofolio',
            array($this, 'dashboard_page')
        );

        add_submenu_page(
            'astrofolio',
            'Télécharger une Image',
            'Upload Image',
            'edit_astro_images',
            'astrofolio-upload',
            array($this, 'upload_image_page')
        );

        add_submenu_page(
            'astrofolio',
            'Galerie',
            'Galerie',
            'edit_astro_images',
            'astrofolio-gallery',
            array($this, 'gallery_page')
        );

        add_submenu_page(
            'astrofolio',
            '🚀 Upload Enhanced',
            '🚀 Upload Enhanced', 
            'edit_astro_images',
            'astrofolio-upload-enhanced',
            array($this, 'upload_enhanced_page')
        );

        add_submenu_page(
            'astrofolio',
            'Catalogues',
            'Catalogues',
            'manage_astro_catalogs',
            'astrofolio-catalogs',
            array($this, 'catalogs_page')
        );

        add_submenu_page(
            'astrofolio',
            '🌐 Gestion Public',
            '🌐 Gestion Public',
            'manage_options',
            'astrofolio-public-admin',
            array($this, 'public_admin_page')
        );

        // Pages de diagnostic (masquées)
        add_submenu_page(
            null,
            'Test Upload',
            'Test Upload',
            'manage_options',
            'astrofolio-test-upload',
            array($this, 'test_upload_page')
        );

        add_submenu_page(
            null,
            'Debug Production',
            'Debug Production',
            'manage_options',
            'astrofolio-debug-production',
            array($this, 'debug_production_page')
        );

        add_submenu_page(
            null,
            'Diagnostic Uploads',
            'Diagnostic Uploads',
            'manage_options',
            'astrofolio-diagnostic-uploads',
            array($this, 'diagnostic_uploads_page')
        );
    }

    public function enqueue_admin_scripts($hook) {
        if (empty($hook) || strpos($hook, 'astrofolio') === false) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_script('jquery');
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');

        wp_enqueue_style(
            'astrofolio-admin',
            ANC_PLUGIN_URL . 'admin/css/admin.css',
            array(),
            ANC_VERSION
        );

        // CSS amélioré pour les métadonnées
        wp_enqueue_style(
            'astrofolio-metadata-enhanced',
            ANC_PLUGIN_URL . 'admin/css/metadata-enhanced.css',
            array('astrofolio-admin'),
            ANC_VERSION
        );

        // CSS pour l'administration publique
        if ($hook === 'astrofolio_page_astrofolio-public-admin') {
            wp_enqueue_style(
                'astrofolio-admin-public',
                ANC_PLUGIN_URL . 'admin/css/admin-public.css',
                array('astrofolio-admin'),
                ANC_VERSION
            );
        }

        wp_enqueue_script(
            'astrofolio-admin',
            ANC_PLUGIN_URL . 'admin/js/admin.js',
            array('jquery', 'media-upload', 'thickbox'),
            ANC_VERSION,
            true
        );

        // JavaScript amélioré pour les métadonnées
        wp_enqueue_script(
            'astrofolio-metadata-enhanced',
            ANC_PLUGIN_URL . 'admin/js/metadata-enhanced.js',
            array('jquery', 'astrofolio-admin'),
            ANC_VERSION,
            true
        );

        // JavaScript pour l'administration publique
        if ($hook === 'astrofolio_page_astrofolio-public-admin') {
            wp_enqueue_script(
                'astrofolio-admin-public',
                ANC_PLUGIN_URL . 'admin/js/admin-public.js',
                array('jquery', 'astrofolio-admin'),
                ANC_VERSION,
                true
            );
            
            wp_localize_script('astrofolio-admin-public', 'astroAdmin', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('astro_admin_nonce')
            ));
        }
    }

    public function dashboard_page() {
        $total_images = $this->count_astro_images();
        $catalog_objects = $this->count_catalog_objects();
        ?>
        <div class="wrap">
            <h1>🚀 AstroFolio Dashboard</h1>
            
            <div class="astro-dashboard-stats">
                <div class="astro-stat-box">
                    <h3>Images Astrophoto</h3>
                    <p class="stat-number"><?php echo $total_images; ?></p>
                    <a href="<?php echo admin_url('admin.php?page=astrofolio-gallery'); ?>" class="button">Voir la galerie</a>
                </div>
                
                <div class="astro-stat-box">
                    <h3>Objets Catalogués</h3>
                    <p class="stat-number"><?php echo number_format($catalog_objects); ?></p>
                    <a href="<?php echo admin_url('admin.php?page=astrofolio-catalogs'); ?>" class="button">Voir les catalogues</a>
                </div>
            </div>

            <div class="astro-quick-actions">
                <a href="<?php echo admin_url('admin.php?page=astrofolio-upload'); ?>" class="button button-primary">📸 Télécharger une Image</a>
                <a href="<?php echo admin_url('admin.php?page=astrofolio-gallery'); ?>" class="button">🖼️ Voir la Galerie</a>
                <a href="<?php echo admin_url('admin.php?page=astrofolio-catalogs'); ?>" class="button">📋 Gérer les Catalogues</a>
            </div>
        </div>

        <style>
        .astro-dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .astro-stat-box {
            background: white;
            padding: 20px;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            text-align: center;
        }
        
        .astro-stat-box h3 {
            margin-top: 0;
            color: #23282d;
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #0073aa;
            margin: 10px 0;
        }
        
        .astro-quick-actions {
            display: flex;
            gap: 10px;
            margin: 30px 0;
            flex-wrap: wrap;
        }
        
        .astro-quick-actions .button {
            padding: 10px 20px;
        }
        </style>
        <?php
    }

    public function upload_image_page() {
        $message = '';
        $message_type = '';
        
        // Traitement du formulaire simple
        if (isset($_POST['upload_image'])) {
            error_log('AstroFolio Debug: Upload simple - traitement');
            
            // Vérification du nonce
            if (!wp_verify_nonce($_POST['upload_nonce'], 'astrofolio_upload')) {
                $message = 'Erreur de sécurité. Veuillez rafraîchir la page et réessayer.';
                $message_type = 'error';
            } else {
                error_log('AstroFolio Debug: Nonce valide');
                
                // Vérification fichier
                if (empty($_FILES['image_file']) || $_FILES['image_file']['error'] !== UPLOAD_ERR_OK) {
                    $message = 'Erreur: Aucun fichier sélectionné ou erreur d\'upload.';
                    $message_type = 'error';
                } else {
                    try {
                        $result = $this->handle_simple_upload();
                        $message = $result['message'];
                        $message_type = $result['success'] ? 'success' : 'error';
                    } catch (Exception $e) {
                        error_log('AstroFolio Debug: Exception: ' . $e->getMessage());
                        $message = 'Erreur système: ' . $e->getMessage();
                        $message_type = 'error';
                    }
                }
            }
        }
        
        ?>
        <div class="wrap">
            <h1>📸 Télécharger une Image Astro</h1>
            
            <?php if ($message): ?>
                <div class="notice notice-<?php echo $message_type; ?> is-dismissible">
                    <p><?php echo esc_html($message); ?></p>
                    <?php if ($message_type === 'success'): ?>
                        <p>
                            <a href="<?php echo admin_url('admin.php?page=astrofolio-gallery'); ?>" class="button button-primary">
                                🖼️ Voir la Galerie
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=astrofolio-upload'); ?>" class="button">
                                📸 Télécharger une Autre Image
                            </a>
                        </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div class="astro-upload-container">
                <h2>📸 Upload d'Image Astrophotographie</h2>
                <p>Uploadez votre image avec les métadonnées essentielles.</p>
                
                <form method="post" enctype="multipart/form-data" class="astro-upload-form">
                    <?php wp_nonce_field('astrofolio_upload', 'upload_nonce'); ?>
                    
                    <!-- Fichier et infos de base -->
                    <div class="upload-section">
                        <h3>📁 Fichier et Informations de Base</h3>
                        
                        <div class="form-field">
                            <label for="image_file">Fichier Image *</label>
                            <input type="file" id="image_file" name="image_file" accept="image/*" required>
                            <p class="description">Formats acceptés : JPG, PNG, GIF. Taille max : <?php echo size_format(wp_max_upload_size()); ?></p>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-field">
                                <label for="title">Titre de l'image *</label>
                                <input type="text" id="title" name="title" required placeholder="ex: M31 - Galaxie d'Andromède">
                            </div>
                            
                            <div class="form-field">
                                <label for="object_name">Nom de l'objet</label>
                                <input type="text" id="object_name" name="object_name" placeholder="M31, NGC 7000...">
                            </div>
                        </div>
                        
                        <div class="form-field">
                            <label for="description">Description</label>
                            <textarea id="description" name="description" rows="3" placeholder="Description de votre image..."></textarea>
                        </div>
                    </div>
                    
                    <!-- Équipement principal -->
                    <div class="upload-section">
                        <h3>🔭 Équipement Principal</h3>
                        
                        <div class="form-row">
                            <div class="form-field">
                                <label for="telescope">Télescope</label>
                                <input type="text" id="telescope" name="telescope" placeholder="Celestron EdgeHD 8...">
                            </div>
                            
                            <div class="form-field">
                                <label for="camera">Caméra</label>
                                <input type="text" id="camera" name="camera" placeholder="ZWO ASI2600MC-Pro...">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Paramètres d'acquisition -->
                    <div class="upload-section">
                        <h3>⚙️ Paramètres d'Acquisition</h3>
                        
                        <div class="form-row">
                            <div class="form-field">
                                <label for="exposure_time">Temps d'exposition</label>
                                <input type="text" id="exposure_time" name="exposure_time" placeholder="300s">
                            </div>
                            
                            <div class="form-field">
                                <label for="iso_gain">ISO/Gain</label>
                                <input type="text" id="iso_gain" name="iso_gain" placeholder="139">
                            </div>
                            
                            <div class="form-field">
                                <label for="number_of_frames">Nombre d'images</label>
                                <input type="text" id="number_of_frames" name="number_of_frames" placeholder="60">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-field">
                                <label for="location">Lieu de prise de vue</label>
                                <input type="text" id="location" name="location" placeholder="Observatoire de...">
                            </div>
                            
                            <div class="form-field">
                                <label for="shooting_date">Date de prise de vue</label>
                                <input type="date" id="shooting_date" name="shooting_date">
                            </div>
                        </div>
                    </div>
                    
                    <p class="submit">
                        <input type="submit" name="upload_image" class="button button-primary button-large" value="📸 Publier l'Image">
                    </p>
                </form>
            </div>
        </div>
        
        <style>
        .astro-upload-container {
            max-width: 1000px;
            margin: 20px 0;
        }
        
        .upload-section {
            background: #f9f9f9;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        
        .upload-section h3 {
            margin-top: 0;
            color: #333;
            font-size: 18px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .form-field {
            margin-bottom: 15px;
        }
        
        .form-field label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }
        
        .form-field input,
        .form-field textarea {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .form-field input:focus,
        .form-field textarea:focus {
            border-color: #0073aa;
            box-shadow: 0 0 5px rgba(0,115,170,0.3);
            outline: none;
        }
        
        .button-large {
            padding: 12px 24px !important;
            font-size: 16px !important;
            height: auto !important;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
        </style>
        
        <?php
    }
    
    /**
     * Upload simple et fonctionnel
     */
    private function handle_simple_upload() {
        error_log('AstroFolio Debug: handle_simple_upload appelé');
        
        if (empty($_FILES['image_file']) || !isset($_FILES['image_file']['error']) || $_FILES['image_file']['error'] !== UPLOAD_ERR_OK) {
            return array('success' => false, 'message' => 'Aucun fichier sélectionné ou erreur d\'upload.');
        }
        
        $uploaded_file = $_FILES['image_file'];
        error_log('AstroFolio Debug: Fichier: ' . $uploaded_file['name']);
        
        // Utiliser la méthode manuelle qui fonctionne
        $upload_result = $this->manual_file_upload($uploaded_file);
        
        if (!$upload_result || isset($upload_result['error']) || empty($upload_result['file'])) {
            return array(
                'success' => false, 
                'message' => 'Erreur upload: ' . (isset($upload_result['error']) ? $upload_result['error'] : 'Fichier non créé')
            );
        }
        
        // Créer l'attachment WordPress
        $attachment = array(
            'guid'           => $upload_result['url'] ?? '',
            'post_mime_type' => $upload_result['type'] ?? 'image/jpeg',
            'post_title'     => sanitize_text_field($_POST['title'] ?? ''),
            'post_content'   => '',
            'post_status'    => 'inherit'
        );
        
        $attachment_id = wp_insert_attachment($attachment, $upload_result['file'] ?? '');
        
        if (is_wp_error($attachment_id)) {
            return array(
                'success' => false,
                'message' => 'Erreur création attachment: ' . $attachment_id->get_error_message()
            );
        }
        
        // Générer les métadonnées
        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once(ABSPATH . 'wp-admin/includes/image.php');
        }
        $file_path = $upload_result['file'] ?? '';
        if (!empty($file_path) && file_exists($file_path)) {
            $metadata = wp_generate_attachment_metadata($attachment_id, $file_path);
            wp_update_attachment_metadata($attachment_id, $metadata);
        }
        
        // Sauvegarder toutes les métadonnées
        $astro_fields = array(
            'title', 'description', 'object_name', 'telescope', 'camera',
            'exposure_time', 'iso_gain', 'number_of_frames', 'location', 'shooting_date'
        );
        
        foreach ($astro_fields as $field) {
            if (isset($_POST[$field]) && !empty($_POST[$field])) {
                update_post_meta($attachment_id, 'astro_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        return array(
            'success' => true,
            'message' => '🎉 Image "' . sanitize_text_field($_POST['title'] ?? 'Sans titre') . '" uploadée avec succès !',
            'attachment_id' => $attachment_id
        );
    }
    
    /**
     * Méthode d'upload manuelle en cas d'échec de wp_handle_upload
     */
    private function manual_file_upload($file) {
        error_log('AstroFolio Debug: Début manual_file_upload');
        
        try {
            if (!isset($file['tmp_name']) || empty($file['tmp_name']) || $file['tmp_name'] === null) {
                return array('error' => 'Fichier temporaire manquant');
            }
            
            if (!file_exists($file['tmp_name'])) {
                return array('error' => 'Fichier temporaire inexistant');
            }
            
            $upload_dir = wp_upload_dir();
            if ($upload_dir['error']) {
                return array('error' => $upload_dir['error']);
            }
            
            // Générer un nom unique
            $filename = sanitize_file_name($file['name'] ?? 'upload_' . time());
            $target_file = $upload_dir['path'] . '/' . $filename;
            
            // S'assurer que le fichier n'existe pas déjà
            $counter = 1;
            $base_filename = $filename;
            while (file_exists($target_file)) {
                $pathinfo = pathinfo($base_filename);
                $filename_part = $pathinfo['filename'] ?? 'upload';
                $extension = $pathinfo['extension'] ?? 'jpg';
                $filename = $filename_part . '-' . $counter . '.' . $extension;
                $target_file = $upload_dir['path'] . '/' . $filename;
                $counter++;
            }
            
            // Méthode 1: move_uploaded_file (standard)
            if (is_uploaded_file($file['tmp_name'])) {
                if (move_uploaded_file($file['tmp_name'], $target_file)) {
                    return array(
                        'file' => $target_file,
                        'url'  => $upload_dir['url'] . '/' . basename($target_file),
                        'type' => $file['type'] ?? 'image/jpeg',
                        'method' => 'manual_move_uploaded'
                    );
                }
            }
            
            // Méthode 2: copy (fallback)
            if (copy($file['tmp_name'], $target_file)) {
                return array(
                    'file' => $target_file,
                    'url'  => $upload_dir['url'] . '/' . basename($target_file),
                    'type' => $file['type'] ?? 'image/jpeg',
                    'method' => 'manual_copy'
                );
            }
            
            return array('error' => 'Toutes les méthodes d\'upload ont échoué');
            
        } catch (Exception $e) {
            error_log('AstroFolio Debug: Exception manual_file_upload: ' . $e->getMessage());
            return array('error' => $e->getMessage());
        }
    }

    public function gallery_page() {
        echo '<div class="wrap">';
        echo '<h1>🖼️ Galerie Astrophoto</h1>';
        echo '<p>Galerie simplifiée - fonctionnalité de base</p>';
        echo '</div>';
    }

    public function upload_enhanced_page() {
        include_once ANC_PLUGIN_DIR . 'test-upload-enhanced.php';
    }

    public function catalogs_page() {
        echo '<div class="wrap">';
        echo '<h1>📋 Catalogues</h1>';
        echo '<p>Gestion des catalogues - fonctionnalité de base</p>';
        echo '</div>';
    }

    private function count_astro_images() {
        $query = new WP_Query(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'meta_query' => array(
                array(
                    'key' => 'astro_title',
                    'compare' => 'EXISTS'
                )
            ),
            'posts_per_page' => -1
        ));
        return $query->found_posts;
    }

    private function count_catalog_objects() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'astro_catalog_objects';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name) {
            return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        }
        return 0;
    }

    // Pages de diagnostic - méthodes simples
    public function test_upload_page() {
        include_once ANC_PLUGIN_DIR . 'test-upload-production.php';
    }

    public function debug_production_page() {
        include_once ANC_PLUGIN_DIR . 'diagnostic-production.php';
    }

    public function diagnostic_uploads_page() {
        include_once ANC_PLUGIN_DIR . 'diagnostic-uploads.php';
    }

    public function public_admin_page() {
        if (!class_exists('Astro_Admin_Public')) {
            require_once ANC_PLUGIN_DIR . 'admin/class-admin-public.php';
        }
        $public_admin = new Astro_Admin_Public();
        $public_admin->admin_page();
    }
}

?>